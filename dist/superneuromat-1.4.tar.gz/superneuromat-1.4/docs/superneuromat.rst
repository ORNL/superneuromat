superneuromat package
=====================

Module contents
---------------

.. automodule:: superneuromat
   :members:
   :show-inheritance:
   :undoc-members:
