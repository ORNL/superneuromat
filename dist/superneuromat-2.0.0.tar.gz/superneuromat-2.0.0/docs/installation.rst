Installation
============

#. Install using ``pip install superneuromat``
#. Update/upgrade using ``pip install superneuromat --upgrade``
