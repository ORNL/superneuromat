SuperNeuroMAT
=============

.. automodule:: superneuromat
   :members:
   :undoc-members:
   :show-inheritance:
