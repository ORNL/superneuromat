Development
===========

#. Clone the ``superneuromat`` repo: ``git clone https://github.com/ORNL/superneuromat.git``
#. Add the path to ``superneuromat`` to your ``$PYTHONPATH``: ``export PYTHONPATH=$PYTHONPATH:/path/to/superneuromat``. 
#. You may want to update the ``$PYTHONPATH`` in your ``.bash_profile`` or ``.bashrc``.