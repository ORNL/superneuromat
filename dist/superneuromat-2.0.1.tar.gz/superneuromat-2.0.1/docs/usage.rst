Usage
=====

#. In a Python script or on a Python interpreter, do ``import superneuromat as snm``
#. The main class can be accessed by ``snn = snm.SNN()``
#. Refer to docstrings in the source code or on the `readthedocs <https://superneuromat.readthedocs.io/en/latest/>`_ page for the API
